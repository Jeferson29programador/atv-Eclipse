package br.uemg.agrega��o;

public class Aa {
private int a1;
private Ba a2;
//inje��o de dependencia
public Aa(Ba b , int a1) {
	this.a1 = a1;
	a2 = b;
}

public int getA1() {
	return a1;
}

public void setA1(int a1) {
	this.a1 = a1;
}

public Ba getA2() {
	return a2;
}

public void setA2(Ba a2) {
	this.a2 = a2;
}

@Override
public String toString() {
	return "Aa [a1=" + a1 + "," + a2 ;
}

}
