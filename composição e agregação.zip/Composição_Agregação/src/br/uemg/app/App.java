package br.uemg.app;
import br.uemg.composi��o.A;
import br.uemg.composi��o.B;

import br.uemg.agrega��o.Aa;
import br.uemg.agrega��o.Ba;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	//composi��o
	A aa1 = new A(10,20,30);  //b1 = 10 , b2=20 ,a1=30
	System.out.println("composi�ao "+aa1);
	aa1.setB1(99);
	System.out.println("composi�ao "+aa1);
	
	aa1 = null; //"destruir A"
	System.out.println("aa1 foi destruido ent�o = " + aa1+"\n");
	
	
	//agrega��o
	Ba b = new Ba(10,20);//b1 = 10, b2 = 20
	Aa aa2 = new Aa(b,30); //a1=30
	System.out.println(aa2);
	
	aa2 = null;//destruir aa2 que e o todo de Aa mas vai destruir o b
	System.out.println(aa2);
	System.out.println(b);
	}

}
