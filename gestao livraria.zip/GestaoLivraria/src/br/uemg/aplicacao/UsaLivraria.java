package br.uemg.aplicacao;

import br.uemg.livraria.Ebook;
import br.uemg.livraria.CarrinhoDeCompras;
import br.uemg.livraria.MiniLivro;
import br.uemg.livraria.LivroFisico;
import br.uemg.livraria.Revista;

public class UsaLivraria {

	public static void main(String[] args) {
		
		LivroFisico lf1 = new LivroFisico("Programando Poo em Java","John Doe",300.00);
		
		Ebook eb1 = new Ebook("Como programar em Jave","Deitel & Deitel",280.00,"mauro.hemerlw@gmail.com");
		
		MiniLivro mn = new MiniLivro("Programando em python","Jeroudi" ,50.00);
		
		CarrinhoDeCompras cc1 = new CarrinhoDeCompras();
		
		Revista rev1 = new Revista("Byte Magazine",100.00);
		
		cc1.insere(lf1);
		cc1.insere(eb1);
		cc1.insere(mn);
		cc1.insere(rev1);
		
		System.out.println("Total de vendas R$ = " + cc1.getTotalVendas());
			

	}

}
