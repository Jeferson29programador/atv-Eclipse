package br.uemg.livraria;

public interface Produto {
	double getPreco();
	// public abstract double getPreco();

}
