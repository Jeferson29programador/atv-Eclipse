package br.uemg.livraria;

public class Revista implements Produto,Promocional{
	private String nome;
	private double preco;
	private final  double DESCONTO_REVISTA=0.30;

	public Revista(String nome, Double preco) {
		super();
		this.nome = nome;
		this.preco = preco;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	@Override
	public double getPreco() {
		return preco;
	}

	public void setPreco(Double preco) {
		this.preco = preco;
	}
	
	@Override
	public boolean aplicaDesconto(double valorDesconto) {
		if(valorDesconto > DESCONTO_REVISTA) {//desconto maior que 30%
			return false;//n�o aplicavel
		}
			//desconto aplicavel
			setPreco(getPreco() - valorDesconto * getPreco());//preco = preco -valor*preco
			
			return true;
	}

	@Override
	public String toString() {
		return "Revista [nome= " + nome + ", preco=" + preco + ", DESCONTO_REVISTA=" + DESCONTO_REVISTA + "]\n";
	}
	
	
	
	
}
