package br.uemg.livraria;

public interface Comparavel<T> {
	public abstract T maior(T x,T y);

}
