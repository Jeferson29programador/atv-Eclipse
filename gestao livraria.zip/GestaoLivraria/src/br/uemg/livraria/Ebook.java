package br.uemg.livraria;

public class Ebook extends Livro implements Promocional{
	private final double DESCONTO_LIVRO_EBOOK = 0.15;  // desconto de 15%
	private String marcaDagua;
	
	//Construtor
	public Ebook(String titulo, String autor, double preco,String md ) {
		super(titulo,autor,preco);	//invoca o construtor da super classe(Livro)
		marcaDagua = md;
	}
	@Override
	public boolean aplicaDesconto(double valorDesconto) {
		if(valorDesconto > DESCONTO_LIVRO_EBOOK) {//desconto maior que 30%
			return false;//n�o aplicavel
		}
			//desconto aplicavel
			setPreco(getPreco() - valorDesconto * getPreco());//preco = preco -valor*preco
			
			return true;
	}
	@Override
	public String toString() {
		return "Ebook " + super.toString()+" DESCONTO_LIVRO_EBOOK= " + DESCONTO_LIVRO_EBOOK + ", marcaDagua= " + marcaDagua  
				 + "]\n";
	}
	
	
} 





