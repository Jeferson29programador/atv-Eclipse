package br.uemg.livraria;

public interface Promocional {
	public abstract boolean aplicaDesconto(double valorDesconto);
}
