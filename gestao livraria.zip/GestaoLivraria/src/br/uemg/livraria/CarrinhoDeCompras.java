package br.uemg.livraria;

public class CarrinhoDeCompras {
	private double totalVendas;

	public CarrinhoDeCompras() {
		totalVendas = 0;
	}

	public void insere(Produto prod) {
		// prod.aplicaDesconto(0.10);//10% de Desconto
		System.out.println(prod);
		totalVendas += prod.getPreco();
	}

	public double getTotalVendas() {
		return totalVendas;
	}
}
