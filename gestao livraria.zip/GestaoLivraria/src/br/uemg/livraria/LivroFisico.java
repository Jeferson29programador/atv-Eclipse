package br.uemg.livraria;

public class LivroFisico extends Livro implements Promocional {
	private final double DESCONTO_LIVRO_FISICO = 0.30; // desconto de 30%

	public LivroFisico(String titulo, String autor, double preco) {
		super(titulo, autor, preco);

	}
	@Override
	public boolean aplicaDesconto(double valorDesconto) {
		if (valorDesconto > DESCONTO_LIVRO_FISICO) {// desconto maior que 30%
			return false;// n�o aplicavel
		}
		// desconto aplicavel
		setPreco(getPreco() - valorDesconto * getPreco());// preco = preco -valor*preco

		return true;
	}
	@Override
	public String toString() {
		return "LivroFisico" + super.toString()+" DESCONTO_LIVRO_FISICO= " + DESCONTO_LIVRO_FISICO + "]\n";
	}
	
}
