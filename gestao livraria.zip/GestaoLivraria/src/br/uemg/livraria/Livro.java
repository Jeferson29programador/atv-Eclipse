package br.uemg.livraria;

public abstract class Livro implements Produto{
	private String titulo;
	private String autor;
	private double preco;
	
	
	//Construtor
	public Livro(String titulo, String autor, double preco) {
		this.titulo = titulo;
		this.autor = autor;
		this.preco = preco;	
	}
	
	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getAutor() {
		return autor;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}

	@Override
	public double getPreco() {
		return preco;
	}

	public void setPreco(double preco) {
		this.preco = preco;
	}
	
	//public abstract boolean aplicaDesconto(double valorDesconto);
//	 {
//			if(valorDesconto > DESCONTO_LIVRO_FISICO) {	//desconto maior que 30%
//				return false;//n�o aplicavel
//			}
//				//desconto aplicavel
//			
//				preco-=valorDesconto*preco;	//preco = preco -valor*preco
//			
//				return true;
//		}

	@Override
	public String toString() {
		return "[titulo= " + titulo + ", autor= " + autor + ", preco= " + preco + "]\n";
	}
		
}





